import calendar
print(calendar.calendar(2021))
