#Write a Python program to print the even numbers from a given list.
lst = [1,2,3,4,5,6]
print(lst)
for i in lst:
    if (i%2) == 0:
        print(i)
    else:
        pass
