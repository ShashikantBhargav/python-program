import time
print("Current date and time:")
print(time.ctime())
