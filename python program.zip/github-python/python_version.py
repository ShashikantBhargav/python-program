import sys
print("python version")
print(sys.version)
#print("version.info")
#print(sys.version_info)
