def pyramid(rows):
    for i in range(rows):
        print(''*(row-1-1)+'x'*(i+1))
    for j in range(rows-1,0,-1):
        print(''*(rows-j)+'x'*(j))
        
