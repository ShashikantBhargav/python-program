import getpass
print(getpass.getuser())
