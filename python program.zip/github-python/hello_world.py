"""#a is a variale that contain value.
a = "Hello world"
#print a
print(a)"""


# hello world using class
class Myclass(object):#object is optional
	def show(self):#self is a variable.
		print("Hello world")
#x is object
x = Myclass()
x.show()
