print("enter length, breath and height of cuboid:")
l=float(input("enter length:"))
b=float(input("enter breath:"))
h=float(input("enter height:"))

v=l*b*h
print("volume is:",v)
