"""def max_of_two(x,y):
    if x>y:
        print("x is big")
    else:
        print("y is big")

x = int(input("enter number x:"))
y = int(input("enter number y:"))        
max_of_two(x,y)"""
    
"""def max():
    a = int(input("enter number:"))
    b = int(input("enter number:"))
    c = int(input("enter number:"))

    if ((a>c) & (a>b)):
        print("a is largest",a)
    elif ((b>a) & (b>c)):
        print("b is largest",b)
    else:
        print("c is largest",c)

max()"""

#Write a Python function to add all the numbers in a list.
"""def sum_lst(*arg):
    return print(sum(arg))

sum_lst(1, 2, 3, 4)"""

#Write a Python function to multiply all the numbers in a list.
"""def mul_of_lst(list):

    mul = 1

    for i in list:
        mul = mul * i
    return mul

list = [1,2,3]

print(mul_of_lst(list))"""



"""from math import factorial
def factorial_n():
    n = int(input('Enter N: '))
    print('Factorial of {0} is {1}'.format(n,factorial(n)))

factorial_n()"""

"""
def factorial(n):
    if n == 0:
        return 1
    else:
        return n * factorial(n-1)
n=int(input("Input a number to compute the factiorial : "))
print(factorial(n))"""

"""lst = [1,2,2,1,3,5,3,4,5]
print(lst)
n = set(lst)
print(n)
my_list = list(n)
print(my_list)"""

#Write a Python program to print the even numbers from a given list.
"""lst = [1,2,3,4,5,6]
print(lst)
for i in lst:
    if (i%2) == 0:
        print(i)
    else:
        pass"""
"""
def is_even_num(l):
    enum = []
    for n in l:
        if n % 2 == 0:
            enum.append(n)
    return enum
print(is_even_num([1, 2, 3, 4, 5, 6, 7, 8, 9]))"""



#Write a Python function to create and print a list where the values
#are square of numbers between 1 and 30 (both included).

def printValues():
	l = list()
	for i in range(1,10):
		l.append(i**2)
	print(l)
		
printValues()














