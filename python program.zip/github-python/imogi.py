print("\U0001F602")

print("\U0001F92A")

print("\U0001F92B")

print("\U0001F605")

print("\U0001F60D")
