def last_word(a):
    arr = a.split(' ')
    
    last_word = arr[-1]

    print(last_word)

a= "shashi kant bhargav"
last_word(a)
