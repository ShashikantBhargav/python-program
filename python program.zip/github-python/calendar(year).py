import calendar

year = int(input("Enter the year:"))


#calendar.setfirstweekday(calendar.MONDAY)

mycal = calendar.calendar(year)

print(mycal)
