num=int(input("enter a number:"))
for count in range(1,11):
    print(num,'*',count,'=',num*count)
