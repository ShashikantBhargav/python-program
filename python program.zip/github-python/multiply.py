def mylist(lst):
    #lst=[3,2,4]
    result=1
    for x in lst:
        result=result*x
    print(result)
mylist([3,2,4])
